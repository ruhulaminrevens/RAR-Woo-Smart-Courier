=== RAR Woo Smart Courier ===
Contributors: ruhulaminrevens
Tags: woocommerce, shipping, courier, bangladesh, delivery
Requires at least: 6.5
Requires PHP: 8.0
Stable tag: 1.3.0
License: GPLv2 or later

Smart multi-courier selector for WooCommerce with dynamic zone/weight pricing, ETA-aware recommendation, free-shipping strike-through pricing, and custom courier support.

== Description ==
RAR Woo Smart Courier is designed for Bangladesh WooCommerce stores that want multiple courier choices without sacrificing native WooCommerce shipping/payment compatibility.

Default storefront names:
* Pathao
* Paperfly
* Steadfast
* Redx
* Sundarban
* One optional custom courier

Default Dhaka presentation:
Pathao · 1–2 business days: 70.00৳ · Rec
Paperfly · 1–2 business days: 70.00৳
Steadfast · 1–3 business days: 70.00৳
Redx · 1–3 business days: 80.00৳
Sundarban · 1–3 business days: 110.00৳

When WooCommerce Free Shipping is active, the normal courier price is retained as strike-through instead of repeating "Free Delivery" on every row.

== Installation ==
1. Upload the ZIP in Plugins > Add New > Upload Plugin.
2. Replace the existing Nabiad Smart Courier plugin if prompted.
3. Open WooCommerce > Smart Courier.
4. Keep Safe Test Mode ON for admin-only testing.
5. Validate Cart, Checkout, COD and Free Shipping.
6. Turn Safe Test Mode OFF and save.

== Changelog ==
= 1.3.0 =
* Renamed project to RAR Woo Smart Courier.
* Compact label format with recommendation at the end: "· Rec".
* Standardized "Redx" display name.
* Updated Dhaka ETAs to realistic ranges instead of one-day promises.
* Added optional sixth Custom Courier row.
* Added Smart vs Manual recommendation modes.
* Preserved native WooCommerce free-shipping threshold behavior.
* Free orders now show only a struck-through normal courier amount.
* Improved district-first zone detection to prevent incorrect city-field classification.
* Added legacy setting/order-meta compatibility for Nabiad Smart Courier v1.x.
* Added HPOS compatibility declaration.
* Improved mobile spacing and production safeguards.
