# Installation / Upgrade

1. Back up the site/database before replacing production shipping code.
2. WordPress Admin → Plugins → Add New → Upload Plugin.
3. Upload `RAR-Woo-Smart-Courier-v1.3.0.zip`.
4. If WordPress detects the previous plugin folder, choose **Replace current with uploaded**.
5. Activate **RAR Woo Smart Courier**.
6. WooCommerce → Smart Courier.
7. Keep **Safe Test Mode** enabled while validating.
8. Confirm your merchant-specific rates and ETAs.
9. Validate paid shipping, free shipping, Dhaka, outside Dhaka, COD and order metadata.
10. Disable Safe Test Mode and save.

Do not enable the old WPCode `Nabiad Smart Courier Engine v1.0.0` at the same time. After v1.3.0 is confirmed, the old snippet can be deleted.
