# Changelog

## 1.3.0 — Final polish

- Project renamed to **RAR Woo Smart Courier**.
- Courier display standardized to Pathao, Paperfly, Steadfast, Redx and Sundarban.
- Recommendation marker shortened and moved to the end as `· Rec`.
- Dhaka ETA defaults changed from aggressive one-day promises to practical ranges.
- Added disabled-by-default sixth **Custom Courier** slot with editable name, pricing and ETA.
- Added Smart vs Manual recommendation modes.
- Added district-first zone classification to avoid incorrect rates when City and District conflict.
- Preserved native WooCommerce Free Shipping and Flat Rate compatibility.
- Free shipping now shows the normal courier price as strike-through without duplicate `Free Delivery` text.
- Added legacy settings and order-meta compatibility.
- Added HPOS compatibility declaration.
- Improved mobile density, validation and fail-safe behavior.
