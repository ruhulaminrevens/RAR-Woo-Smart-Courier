# RAR Woo Smart Courier

Production-oriented WooCommerce multi-courier selector for Bangladesh stores.

## Storefront output

```text
Pathao · 1–2 business days: 70.00৳ · Rec
Paperfly · 1–2 business days: 70.00৳
Steadfast · 1–3 business days: 70.00৳
Redx · 1–3 business days: 80.00৳
Sundarban · 1–3 business days: 110.00৳
```

A sixth **Custom Courier** slot is available in WooCommerce → Smart Courier and is disabled by default.

## Features

- Five built-in couriers + one custom courier slot
- Dhaka / Nearby / Outside Bangladesh rate matrix
- Weight-aware pricing (`≤1kg`, `≤2kg`, additional kg)
- Editable ETA by courier and zone
- Smart recommendation: fastest ETA → lower rate → tie priority
- Optional manual-priority recommendation mode
- Compact `· Rec` marker at the end of the selected recommendation
- Native WooCommerce Free Shipping compatibility
- Free orders keep every courier selectable and strike through the normal courier charge
- WooCommerce Flat Rate identity retained for checkout/payment compatibility
- Safe Test Mode (admins only)
- Selected courier, ETA and normal rate stored on the order
- Legacy Nabiad Smart Courier v1.x settings/order-meta compatibility
- HPOS compatibility declaration
- Mobile-compact labels
- Fails safe: original WooCommerce rates remain when no compatible Flat Rate exists

## Upgrade from Nabiad Smart Courier v1.2.0

Upload this plugin ZIP and choose **Replace current with uploaded**. The plugin intentionally keeps the legacy option key so existing merchant-specific rates can survive the upgrade. v1.3.0 only normalizes the five display names, Dhaka ETA defaults and adds the custom courier slot.

After validation, the old WPCode snippet **Nabiad Smart Courier Engine v1.0.0** should remain OFF and may be deleted to eliminate accidental double-engine conflicts.

## Production checklist

1. WooCommerce → Settings → Shipping → **Hide shipping rates when free shipping is available** should remain **unchecked**.
2. Each matched zone should contain a usable Flat Rate; Free Shipping may also be enabled.
3. WooCommerce → Smart Courier → keep **Safe Test Mode ON** for initial tests.
4. Test one paid cart below the free threshold.
5. Test one free-shipping cart above the threshold.
6. Test Dhaka and one outside district.
7. Test COD and place a test order; confirm the chosen courier appears in the order.
8. Turn **Safe Test Mode OFF** and save.

## Version

Current stable: **v1.3.0**

## License

GPL-2.0-or-later
