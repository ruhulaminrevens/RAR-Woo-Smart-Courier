# RAR Woo Smart Courier

**Bangladesh-focused smart multi-courier shipping selector for WooCommerce** — zone, weight, ETA, price, Free Shipping এবং configurable recommendation logic এক জায়গা থেকে manage করার জন্য।

Current stable release: **v1.3.0**

> Built and tested around the Nabiad.com WooCommerce workflow, but the plugin is designed so it can be reused on other WooCommerce stores after merchant-specific rates/zones are configured.

## Latest Download

**[Download RAR Woo Smart Courier v1.3.0](https://github.com/ruhulaminrevens/RAR-Woo-Smart-Courier/raw/main/releases/rar-woo-smart-courier-v1.3.0.zip)**

## What this plugin does

WooCommerce-এর normal shipping flow replace না করে available shipping rates-এর উপর Smart Courier layer যোগ করে। Customer Cart/Checkout-এ courier options দেখতে পায়, system zone + parcel weight + configured rate + ETA অনুযায়ী charge calculate করে এবং suitable option-এ ছোট **`· Rec`** marker দেখায়।

Default presentation example:

```text
Pathao · 1–2 business days: 70.00৳ · Rec
Paperfly · 1–2 business days: 70.00৳
Steadfast · 1–3 business days: 70.00৳
Redx · 1–3 business days: 80.00৳
Sundarban · 1–3 business days: 110.00৳
```

Courier name-এর পরে unnecessary “Courier/Delivery” text যোগ করা হয় না, যাতে desktop ও mobile দুই জায়গায় list compact থাকে।

## Main Features

- **Dhaka / Nearby / Outside Dhaka** zone-based pricing
- **Weight-aware rates** — up to 1 kg, up to 2 kg এবং extra/kg
- **Editable ETA** per courier and per zone
- **Smart recommendation** — faster ETA → lower rate → configured Priority (tie-break)
- Recommendation marker line-এর শেষে compact **`· Rec`**
- **Native WooCommerce Free Shipping compatibility**
- Free Shipping active হলে সব courier selectable থাকে at ৳0, কিন্তু normal courier amount **strike-through** হিসেবে visible থাকে
- Repeated “Free Delivery” text removed for cleaner UI
- **Safe Test Mode** — admin/store manager testing before public rollout
- Selected courier order metadata-তে save হয়
- WooCommerce admin order details/list-এ courier information visible
- Mobile shipping list compact styling
- **Sixth Custom Courier slot** — blank/disabled by default; future courier name, rate, ETA, priority configure করা যায়
- Configurable **Nearby districts** এবং **Nearby cities/areas**
- Existing compatible WooCommerce shipping setup না পেলে original rates preserve করার safety behavior

## Recommendation Workflow

Recommendation logic intentionally simple এবং configurable:

1. Customer shipping address থেকে zone determine করা হয়.
2. Cart/package weight থেকে courier charge calculate করা হয়.
3. Enabled courierগুলোর ETA compare করা হয়.
4. Faster ETA first.
5. ETA tie হলে lower rate first.
6. ETA + rate দুইটাই tie হলে lower **Priority number** wins.
7. First ranked option-এ `· Rec` marker দেখানো হয়.

Priority কোনো courier-কে সবসময় force করে না; এটা **tie-breaker** হিসেবে কাজ করে।

## Free Shipping Workflow

WooCommerce native **Free Shipping** available হলে plugin customer-কে courier choice হারাতে দেয় না।

Example:

```text
Redx · 1–3 business days: 120.00৳   ← normal amount shown strike-through in UI
Paperfly · 1–3 business days: 130.00৳
Pathao · 2–3 business days: 130.00৳
Steadfast · 1–4 business days: 130.00৳
Sundarban · 2–4 business days: 150.00৳
```

Actual shipping cost becomes **৳0**, while the normal configured courier charge remains visually available as reference. “Free Delivery” বারবার প্রতিটি line-এ repeat করা হয় না।

## Admin Settings

Go to:

**WordPress Admin → WooCommerce → Smart Courier**

From there you can manage:

- Engine Enabled / Disabled
- Safe Test Mode
- Fallback parcel weight
- Nearby districts
- Nearby cities/areas
- Courier enable/disable
- Priority
- Dhaka ≤1kg / ≤2kg / Extra per kg
- Nearby ≤1kg / ≤2kg / Extra per kg
- Outside ≤1kg / ≤2kg / Extra per kg
- ETA for Dhaka / Nearby / Outside
- Custom Courier name and rates

## Installation & Safe Deployment

1. Download the latest ZIP from the link above.
2. WordPress → **Plugins → Add New → Upload Plugin**.
3. Upload `rar-woo-smart-courier-v1.3.0.zip` and activate it.
4. WooCommerce → **Smart Courier**.
5. Keep **Safe Test Mode ON** first.
6. Verify merchant-specific rates, ETA, Nearby locations and Free Shipping rule.
7. Test **Cart**, **Checkout**, address change, quantity/weight change, paid shipping, free shipping and COD order creation.
8. Confirm selected courier is saved in the order/admin view.
9. When everything is verified, turn **Safe Test Mode OFF** and click **Save Courier Settings**.

### Old WPCode snippet

If the old **`Nabiad Smart Courier Engine v1.0.0`** WPCode snippet still exists, keep it **OFF** while this plugin is active. After the plugin is verified in production, the old snippet can be deleted to prevent accidental double-engine/conflicting hooks.

## Screenshots

### 1. Smart Courier Settings
![Smart Courier Settings](docs/screenshots/smart-courier-settings.jpg)

### 2. Cart Courier Selector
![Cart Courier Selector](docs/screenshots/cart-courier-selector.jpg)

### 3. Free Delivery / Order Result
![Free Delivery Order](docs/screenshots/order-free-delivery.jpg)

### 4. WooCommerce Admin Order Courier
![Admin Order Courier](docs/screenshots/admin-order-courier.jpg)

## Version Update History

| Version | Update |
|---|---|
| **v1.3.0** | Final courier-line polish, `· Rec` at the end, `Redx` display naming, realistic default ETA ranges, sixth Custom Courier slot, configurable Nearby locations, mobile polish and Free Shipping strike-through behavior retained. |
| **v1.2.0** | Settings/admin workflow stabilization, configurable courier pricing/ETA/priority and improved recommendation/free-shipping presentation. |
| **v1.1.2** | Free Shipping compatibility/fix so courier choices stay available while shipping becomes free. |
| **v1.1.1** | Safe Test Mode build for admin-only verification before public rollout. |
| **v1.1.0** | First installable Smart Courier plugin baseline. |
| **v1.0.0** | Earlier Nabiad Smart Courier Engine WPCode prototype; keep disabled when the plugin is active. |

Full release notes: **[CHANGELOG.md](CHANGELOG.md)**

## Technical Notes

- Requires WordPress + WooCommerce.
- Uses WooCommerce shipping hooks rather than a separate courier API integration.
- Courier rates are merchant-configured; this plugin does not automatically pull live commercial courier tariffs.
- Selected courier data is stored with the WooCommerce order/shipping data for operational visibility.
- Always validate production rates and business-day estimates before deployment.

## License

GPL-2.0-or-later
