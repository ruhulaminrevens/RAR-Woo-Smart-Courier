# RAR Woo Smart Courier

Production-focused multi-courier shipping selector for WooCommerce, designed for Bangladesh zone-based delivery pricing.

## Download

### [⬇️ Download Stable v1.3.0 Installable ZIP](https://github.com/ruhulaminrevens/RAR-Woo-Smart-Courier/raw/main/releases/rar-woo-smart-courier-v1.3.0.zip)

### [📦 Download Latest Source ZIP](https://github.com/ruhulaminrevens/RAR-Woo-Smart-Courier/archive/refs/heads/main.zip)

### [🔒 Download Stable v1.3.0 Source ZIP](https://github.com/ruhulaminrevens/RAR-Woo-Smart-Courier/archive/refs/heads/v1.3.0.zip)

**Install:** WordPress → Plugins → Add New → Upload Plugin → choose the **Installable ZIP** → Install Now → Activate.

## What it does

- Five built-in courier choices: Pathao, Paperfly, Steadfast, Redx and Sundarban
- Sixth optional custom courier slot
- Dhaka / Nearby / Outside Dhaka pricing zones
- Configurable Nearby districts and cities/areas
- Weight-aware pricing for ≤1 kg, ≤2 kg and extra kg
- Separate ETA per courier and delivery zone
- Smart recommendation order: faster ETA → lower rate → lower priority number
- Native WooCommerce Free Shipping compatibility
- Free-shipping orders keep all enabled courier choices visible at ৳0 while showing the normal courier charge as strike-through reference
- Safe Test Mode for administrator/store-manager verification before public rollout
- Selected courier and ETA saved with the WooCommerce order
- Courier visible in the classic WooCommerce admin order screen/list
- Compact mobile shipping labels
- Fail-safe behavior: if a suitable WooCommerce base shipping rate is unavailable, the original WooCommerce rates are left untouched

## Storefront display

Normal paid delivery example:

```text
Pathao · 1–2 business days: 70.00৳ · Rec
Paperfly · 1–2 business days: 70.00৳
Steadfast · 1–3 business days: 70.00৳
Redx · 1–3 business days: 80.00৳
Sundarban · 1–3 business days: 110.00৳
```

When native WooCommerce Free Shipping is available, the courier options stay selectable and the configured amount is displayed with strike-through instead of repeating “Free Delivery” on every row.

## Recommendation logic

1. Determine the shipping zone from the checkout address.
2. Calculate package weight.
3. Calculate the configured rate and ETA for every enabled courier.
4. Prefer the lowest ETA score.
5. If ETA ties, prefer the lower normal courier rate.
6. If both tie, the lower Priority number wins.
7. The first-ranked courier receives the `· Rec` marker.

## Admin settings

Go to **WooCommerce → Smart Courier**.

You can configure:

- Engine ON/OFF
- Safe Test Mode
- Fallback parcel weight
- Nearby districts
- Nearby cities/areas
- Courier enable/disable
- Courier display name
- Priority
- Dhaka / Nearby / Outside pricing
- ETA for each zone
- Custom courier

## Deployment checklist

1. Install and activate the plugin.
2. Keep **Safe Test Mode ON**.
3. Test Cart and Checkout with Dhaka, Nearby and Outside addresses.
4. Test quantity/weight changes.
5. Test normal paid shipping.
6. Test native WooCommerce Free Shipping threshold behavior.
7. Place a test COD order and confirm the selected courier appears in the order.
8. Turn **Safe Test Mode OFF** only after the checks pass.

## Repository structure

```text
RAR-Woo-Smart-Courier/
├── rar-woo-smart-courier.php
├── includes/
│   └── class-rwsc-plugin.php
├── docs/
│   ├── INSTALLATION.md
│   └── screenshots/
├── releases/
│   └── rar-woo-smart-courier-v1.3.0.zip
├── README.md
├── CHANGELOG.md
├── readme.txt
├── LICENSE
├── uninstall.php
└── .gitignore
```

## Compatibility

- WordPress 6.5+
- WooCommerce 8.0+
- PHP 8.0+
- Built around WooCommerce's classic shipping-rate hooks and classic Cart/Checkout workflow
- Cart/Checkout Blocks compatibility is **not declared** in v1.3.0

## Upgrade note

If an older WPCode/custom Smart Courier engine still exists, keep that old engine **OFF** while this plugin is active. After production verification, remove the obsolete duplicate engine to prevent two shipping engines from filtering the same WooCommerce rates.

## Screenshots

### Smart Courier Settings
![Smart Courier Settings](docs/screenshots/smart-courier-settings.jpg)

### Cart Courier Selector
![Cart Courier Selector](docs/screenshots/cart-courier-selector.jpg)

### WooCommerce Admin Order Courier
![Admin Order Courier](docs/screenshots/admin-order-courier.jpg)

## Version

**v1.3.0 — 2026-09-20**

See [CHANGELOG.md](CHANGELOG.md) for version history.

## License

GPL-2.0-or-later
